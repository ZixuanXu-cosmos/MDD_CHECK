# DarkHistory

[<img src="https://travis-ci.org/hongwanliu/DarkHistory.svg?branch=development">](https://travis-ci.org/hongwanliu/DarkHistory)
[<img src="https://readthedocs.org/projects/darkhistory/badge/?version=development">](https://readthedocs.org/projects/darkhistory/)

DarkHistory is a Python code package that calculates the global temperature and ionization history of the universe given an exotic source of energy injection, such as dark matter annihilation or decay. DarkHistory is described in a paper available at [arXiv:1904.09296](https://arxiv.org/abs/1904.09296). Please cite this paper if you use DarkHistory in a scientific publication. For more information, please visit our webpage [here](https://darkhistory.readthedocs.io).
