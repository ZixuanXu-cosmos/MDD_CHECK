"""Classes and functions for manipulating spectra.
"""
