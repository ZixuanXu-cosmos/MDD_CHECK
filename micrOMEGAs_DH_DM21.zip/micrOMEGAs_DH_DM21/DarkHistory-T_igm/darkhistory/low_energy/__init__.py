"""Functions for low-energy deposition and f_c(z). 
"""