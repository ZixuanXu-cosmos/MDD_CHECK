"""Inverse Compton scattering modules.
"""